<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SerachController extends Controller
{
    public function s(Request $request){
        // $results = DB::table('ads')->where('category',$id)->get();
        return response()->json([
            // 'data' => $results,
            'message' => 'Search by category ads fetched successfully!',
        ], 200);
    }
}
