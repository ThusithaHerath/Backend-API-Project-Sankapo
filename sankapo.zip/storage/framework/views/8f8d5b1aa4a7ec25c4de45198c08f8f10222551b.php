<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\WW\OneDrive\Desktop\New folder\sankapo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>