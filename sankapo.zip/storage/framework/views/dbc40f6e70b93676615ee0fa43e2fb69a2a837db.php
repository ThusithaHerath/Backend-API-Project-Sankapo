<div>
   <a href="Sankapo.com/login">login</a>
</div><?php /**PATH C:\Users\WW\OneDrive\Desktop\New folder\sankapo\resources\views/resetPasswords/loginAfterReset.blade.php ENDPATH**/ ?>